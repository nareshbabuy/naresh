package com.oss.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.Cart;
import com.oss.model.Product;

@Repository("cartDao")
public class CartDaoImpl extends AbstractDao<Integer, Cart>implements CartDao {

	static final Logger logger = LoggerFactory.getLogger(CartDaoImpl.class);

	public void save(Cart cart) {
		persist(cart);
	}

	@Override
	public List<Cart> findCartItemsByUserId(int userId, int isOrdered) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("user.id", userId));
		crit.add(Restrictions.eq("isOrdered", isOrdered));
		return (List<Cart>) crit.list();
	}
	
	@Override
	public void deleteById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("id", id));
		Cart cartItem = (Cart) crit.uniqueResult();
		delete(cartItem);

	}

}
