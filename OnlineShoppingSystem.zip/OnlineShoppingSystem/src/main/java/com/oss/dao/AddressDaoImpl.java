package com.oss.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.Address;

@Repository("addressDao")
public class AddressDaoImpl extends AbstractDao<Integer, Address>implements AddressDao {

	static final Logger logger = LoggerFactory.getLogger(AddressDaoImpl.class);

	@Override
	public void save(Address address) {
		System.out.println("Name "+address.getName());
		
		/*System.out.println("cou "+address.getCountry().getId());
		System.out.println("state "+address.getState().getId());
		System.out.println("city "+address.getCity().getId());*/
		persist(address);
	}

	@Override
	public List<Address> findByUserId(int userId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("user.id", userId));
		return (List<Address>) crit.list();
	}

	@Override
	public void deleteById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("addId", id));
		Address address = (Address) crit.uniqueResult();
		delete(address);

	}

	@Override
	public Address findById(int id) {
		return getByKey(id);
	}

}
