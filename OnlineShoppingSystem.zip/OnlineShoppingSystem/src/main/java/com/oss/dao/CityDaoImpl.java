package com.oss.dao;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.City;

@Repository("cityDao")
public class CityDaoImpl extends AbstractDao<Integer, City>implements CityDao {

	static final Logger logger = LoggerFactory.getLogger(CartDaoImpl.class);

	@Override
	public List<City> findByStateId(int stateId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("state.id", stateId));
		return (List<City>) crit.list();
	}

	@Override
	public City findById(int id) throws UnsupportedEncodingException {
		return getByKey(id);
	}

	@Override
	public List<City> findAll() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("name"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);// To avoid
																		// duplicates.
		return (List<City>) criteria.list();
	}

}
