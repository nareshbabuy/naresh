package com.oss.dao;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Country;

public interface CountryDao {

	public List<Country> findAll();
	
	Country findById(int id) throws UnsupportedEncodingException;

}
