package com.oss.dao;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.Country;

@Repository("countryDao")
public class CountryDaoImpl extends AbstractDao<Integer, Country>implements CountryDao {

	static final Logger logger = LoggerFactory.getLogger(CartDaoImpl.class);

	@Override
	public List<Country> findAll() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("name"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);// To avoid
																		// duplicates.
		return (List<Country>) criteria.list();
	}

	@Override
	public Country findById(int id) throws UnsupportedEncodingException {
		return getByKey(id);
	}

}
