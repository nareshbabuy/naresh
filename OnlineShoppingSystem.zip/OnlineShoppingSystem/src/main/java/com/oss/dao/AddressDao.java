package com.oss.dao;

import java.util.List;

import com.oss.model.Address;

public interface AddressDao {

	public List<Address> findByUserId(int userId);

	public void deleteById(int id);

	public void save(Address address);

	Address findById(int id);
}
