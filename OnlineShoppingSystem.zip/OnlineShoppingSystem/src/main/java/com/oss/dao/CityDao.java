package com.oss.dao;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.City;
import com.oss.model.Country;

public interface CityDao {

	public List<City> findByStateId(int stateId);
	
	City findById(int id) throws UnsupportedEncodingException;
	
	public List<City> findAll();

}
