package com.oss.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.Card;

@Repository("cardDao")
public class CardDaoImpl extends AbstractDao<Integer, Card>implements CardDao {

	static final Logger logger = LoggerFactory.getLogger(CardDaoImpl.class);

	@Override
	public void save(Card card) {
		persist(card);
	}

	@Override
	public List<Card> findByUserId(int userId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("user.id", userId));
		return (List<Card>) crit.list();
	}

	@Override
	public void deleteById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("cardId", id));
		Card card = (Card) crit.uniqueResult();
		delete(card);

	}

	@Override
	public Card findById(int id) {
		return getByKey(id);
	}

}
