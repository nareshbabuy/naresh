package com.oss.dao;

import java.util.List;

import com.oss.model.Cart;

public interface CartDao {

	public void save(Cart cart);

	public List<Cart> findCartItemsByUserId(int userId, int isOrdered);

	public void deleteById(int id);
}
