package com.oss.dao;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Country;
import com.oss.model.State;

public interface StateDao {

	public List<State> findByCountryId(int countryId);

	State findById(int id) throws UnsupportedEncodingException;
	
	public List<State> findAll();

}
