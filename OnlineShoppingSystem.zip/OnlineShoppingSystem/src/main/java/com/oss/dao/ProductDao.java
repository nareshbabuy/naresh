package com.oss.dao;

import java.util.List;

import com.oss.model.Product;

public interface ProductDao {

	Product findById(int id);

	// User findBySSO(String sso);

	void save(Product product);

	void deleteById(int id);

	List<Product> findAllProducts();

	List<Product> searchProducts(String productDetails, String productType);

}
