package com.oss.dao;

import java.util.List;

import com.oss.model.Address;
import com.oss.model.Card;

public interface CardDao {

	public List<Card> findByUserId(int userId);

	public void deleteById(int id);

	public void save(Card card);

	Card findById(int id);
}
