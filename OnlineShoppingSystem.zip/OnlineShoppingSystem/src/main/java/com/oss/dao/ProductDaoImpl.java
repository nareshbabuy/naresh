package com.oss.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.oss.model.Product;

@Repository("productDao")
public class ProductDaoImpl extends AbstractDao<Integer, Product>implements ProductDao {

	static final Logger logger = LoggerFactory.getLogger(ProductDaoImpl.class);

	public Product findById(int id) {
		Product product = getByKey(id);
		return product;
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public List<Product> searchProducts(String productDetails, String productType) {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("name"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (productDetails != null) {
			Criterion name = Restrictions.like("name", "%" + productDetails + "%");
			Criterion description = Restrictions.like("description", "%" + productDetails + "%");

			LogicalExpression orExp = Restrictions.or(name, description);

			criteria.add(orExp);
		}

		if (!productType.contains("Select")) {
			criteria.add(Restrictions.like("productType", "%" + productType + "%"));
		}

		List<Product> products = (List<Product>) criteria.list();

		return products;
	}

	public List<Product> findAllProducts() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("name"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<Product> products = (List<Product>) criteria.list();

		return products;
	}

	public void save(Product product) {
		persist(product);
	}

	@Override
	public void deleteById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("id", id));
		Product product = (Product) crit.uniqueResult();
		delete(product);

	}

}
