package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.CardDao;
import com.oss.model.Card;
import com.oss.vo.CardVo;

@Service("cardService")
@Transactional
public class CardServiceImpl implements CardService {

	@Autowired
	private CardDao dao;

	@Override
	public void save(Card card) throws IOException {

		dao.save(card);
	}

	@Override
	public List<Card> findByUserId(int userId) throws UnsupportedEncodingException {
		return dao.findByUserId(userId);
	}

	@Override
	public List<CardVo> findCardVoByUserId(int userId) throws UnsupportedEncodingException {
		List<Card> cardLst = findByUserId(userId);
		if (cardLst != null) {
			List<CardVo> cardVoLst = new ArrayList<CardVo>();
			for (Card card : cardLst) {

				cardVoLst.add(cardToCardVo(card));
			}

			return cardVoLst;
		}
		return null;
	}

	private CardVo cardToCardVo(Card card) {

		if (card != null) {
			CardVo cardVo = new CardVo();

			cardVo.setCardId(card.getCardId());
			cardVo.setCardNumber(maskNumber(card.getCardNumber(), "####XXXXXXXX####"));
			cardVo.setCvv(maskNumber(card.getCvv(), "XXX"));
			cardVo.setMonth(card.getMonth());
			cardVo.setName(card.getName());
			cardVo.setUser(card.getUser());
			cardVo.setYear(card.getYear());

			return cardVo;
		}
		return null;
	}

	public static String maskNumber(String number, String mask) {

		int index = 0;
		StringBuilder masked = new StringBuilder();
		for (int i = 0; i < mask.length(); i++) {
			char c = mask.charAt(i);
			if (c == '#') {
				masked.append(number.charAt(index));
				index++;
			} else if (c == 'X') {
				masked.append(c);
				index++;
			} else {
				masked.append(c);
			}
		}
		return masked.toString();
	}

	public void deleteById(int id) {
		dao.deleteById(id);
	}

	public void update(Card card) throws IOException {
		Card entity = dao.findById(card.getCardId());

		if (entity != null) {
			entity.setName(card.getName());
			entity.setCardNumber(card.getCardNumber());
			entity.setCvv(card.getCvv());
			entity.setMonth(card.getMonth());
			entity.setYear(card.getYear());

		}

	}

	@Override
	public CardVo findCardVoById(int id) throws UnsupportedEncodingException {
		return cardToCardVo(dao.findById(id));
	}

	@Override
	public Card findById(int id) throws UnsupportedEncodingException {
		return dao.findById(id);
	}

}
