package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.CityDao;
import com.oss.model.City;
import com.oss.vo.KeyValue;

@Service("cityService")
@Transactional
public class CityServiceImpl implements CityService {

	@Autowired
	private CityDao dao;

	@Override
	public List<KeyValue> findByStateId(int stateId) throws UnsupportedEncodingException {
		List<KeyValue> keyValueList = new ArrayList<>();
		for (City city : dao.findByStateId(stateId)) {
			keyValueList.add(new KeyValue(city.getId(), city.getName()));
		}
		return keyValueList;
	}

	@Override
	public City findById(int id) throws UnsupportedEncodingException {
		return dao.findById(id);
	}

	@Override
	public List<KeyValue> findAll() {
		List<KeyValue> keyValueList = new ArrayList<>();
		for (City entity : dao.findAll()) {
			keyValueList.add(new KeyValue(entity.getId(), entity.getName()));
		}
		return keyValueList;
	}

}
