package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Address;
import com.oss.vo.AddressVO;

public interface AddressService {

	void save(Address address) throws IOException;

	public List<Address> findByUserId(int userId) throws UnsupportedEncodingException;

	public void deleteById(int id);

	Address findById(int id) throws UnsupportedEncodingException;

	void updateAddress(Address address) throws IOException;

	public List<AddressVO> findVOByUserId(int userId) throws UnsupportedEncodingException;

	AddressVO findVOById(int id) throws UnsupportedEncodingException;
}