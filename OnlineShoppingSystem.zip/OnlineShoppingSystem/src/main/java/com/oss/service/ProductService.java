package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.vo.ProductVO;

public interface ProductService {

	// User findBySSO(String sso);

	void saveProduct(ProductVO productVO) throws IOException;

	// void updateUser(User user);

	void deleteProductById(int id);

	List<ProductVO> findAllProducts() throws UnsupportedEncodingException;

	List<ProductVO> searchProducts(String productDetails, String productType) throws UnsupportedEncodingException;

	ProductVO findById(int id) throws UnsupportedEncodingException;

	void updateProduct(ProductVO productVO) throws IOException;

	// boolean isUserSSOUnique(Integer id, String sso);

}