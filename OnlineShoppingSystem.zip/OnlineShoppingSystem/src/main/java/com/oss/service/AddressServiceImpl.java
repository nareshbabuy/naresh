package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.AddressDao;
import com.oss.dao.CityDao;
import com.oss.dao.CountryDao;
import com.oss.dao.StateDao;
import com.oss.model.Address;
import com.oss.model.City;
import com.oss.model.Country;
import com.oss.model.State;
import com.oss.vo.AddressVO;

@Service("addressService")
@Transactional
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressDao dao;

	@Autowired
	private CountryDao countrydao;

	@Autowired
	private StateDao statedao;

	@Autowired
	private CityDao citydao;

	@Override
	public void save(Address address) throws IOException {

		dao.save(address);
	}

	@Override
	public List<Address> findByUserId(int userId) throws UnsupportedEncodingException {
		return dao.findByUserId(userId);
	}

	public void deleteById(int id) {
		dao.deleteById(id);
	}

	public void updateAddress(Address address) throws IOException {
		Address entity = dao.findById(address.getAddId());
		if (entity != null) {
			entity.setName(address.getName());
			entity.setAddress(address.getAddress());
			entity.setLandmark(address.getLandmark());

			entity.setCity(address.getCity());
			entity.setState(address.getState());
			entity.setCountry(address.getCountry());
			entity.setPincode(address.getPincode());
			entity.setPhone(address.getPhone());
		}
	}

	@Override
	public Address findById(int id) throws UnsupportedEncodingException {
		return dao.findById(id);
	}
	
	@Override
	public AddressVO findVOById(int id) throws UnsupportedEncodingException {
		return addressToAddressVO(dao.findById(id));
	}

	@Override
	public List<AddressVO> findVOByUserId(int userId) throws UnsupportedEncodingException {
		List<Address> addressList = dao.findByUserId(userId);
		if (addressList != null) {
			List<AddressVO> addressVOList = new ArrayList<AddressVO>();
			for (Address address : addressList) {
				addressVOList.add(addressToAddressVO(address));
			}

			return addressVOList;
		}
		return null;
	}

	private AddressVO addressToAddressVO(Address address) throws UnsupportedEncodingException {
		if (address != null) {
			AddressVO addressVO = new AddressVO();
			addressVO.setAddId(address.getAddId());
			addressVO.setAddress(address.getAddress());

			Country coutry = countrydao.findById(address.getCountry());
			if (coutry != null)
				addressVO.setCountryName(coutry.getName());

			State state = statedao.findById(address.getState());
			if (state != null)
				addressVO.setStateName(state.getName());

			City city = citydao.findById(address.getCity());
			if (city != null)
				addressVO.setCityName(city.getName());

			addressVO.setLandmark(address.getLandmark());
			addressVO.setName(address.getName());
			addressVO.setPhone(address.getPhone());
			addressVO.setPincode(address.getPincode());

			return addressVO;
		}
		return null;

	}

}
