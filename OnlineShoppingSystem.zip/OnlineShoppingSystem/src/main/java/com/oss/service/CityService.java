package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.City;
import com.oss.vo.KeyValue;

public interface CityService {

	public List<KeyValue> findByStateId(int stateId) throws UnsupportedEncodingException;
	City findById(int id) throws UnsupportedEncodingException;
	
	public List<KeyValue> findAll();

}