package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Card;
import com.oss.model.Cart;
import com.oss.vo.CartVO;

public interface CartService {

	void save(List<Cart> cartItems) throws IOException;

	public List<CartVO> findCartItemsByUserId(int userId, int isOrdered) throws UnsupportedEncodingException;

	public void deleteById(int id);

	List<Cart> findByUserId(int userId, int isOrdered) throws UnsupportedEncodingException;
	
	void updateForOrder(int userId) throws IOException;
}