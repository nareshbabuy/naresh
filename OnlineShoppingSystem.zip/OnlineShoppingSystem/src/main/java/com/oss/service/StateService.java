package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.State;
import com.oss.vo.KeyValue;

public interface StateService {

	public List<KeyValue> findByCountryId(int countryId) throws UnsupportedEncodingException;

	State findById(int id) throws UnsupportedEncodingException;
	
	public List<KeyValue> findAll();

}