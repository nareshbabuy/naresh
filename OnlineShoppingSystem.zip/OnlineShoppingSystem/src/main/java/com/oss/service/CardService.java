package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Card;
import com.oss.vo.CardVo;

public interface CardService {

	void save(Card Card) throws IOException;

	public List<Card> findByUserId(int userId) throws UnsupportedEncodingException;

	public void deleteById(int id);

	Card findById(int id) throws UnsupportedEncodingException;

	void update(Card card) throws IOException;

	List<CardVo> findCardVoByUserId(int userId) throws UnsupportedEncodingException;

	CardVo findCardVoById(int id) throws UnsupportedEncodingException;
}