package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.oss.model.Country;
import com.oss.vo.KeyValue;

public interface CountryService {

	public List<KeyValue> findAll();

	Country findById(int id) throws UnsupportedEncodingException;
}