package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.ProductDao;
import com.oss.model.Product;
import com.oss.vo.ProductVO;

@Service("productService")
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao dao;

	public ProductVO findById(int id) throws UnsupportedEncodingException {
		return productToProductVO(dao.findById(id));
	}

	private void productVOToProduct(ProductVO productVO, Product product) throws IOException {

		product.setName(productVO.getName());
		product.setDescription(productVO.getDescription());
		System.out.println("ddd " + productVO.getFile());
		System.out.println("ddd size " + productVO.getFile().getBytes());
		if (productVO.getFile() != null && productVO.getFile().getSize() != 0) {
			product.setImage(productVO.getFile().getBytes());
		}
		product.setPrice(productVO.getPrice());
		product.setProductType(productVO.getProductType());
	}

	public void saveProduct(ProductVO productVO) throws IOException {

		Product product = new Product();
		productVOToProduct(productVO, product);
		dao.save(product);
	}

	/*
	 * Since the method is running with Transaction, No need to call hibernate
	 * update explicitly. Just fetch the entity from db and update it with
	 * proper values within transaction. It will be updated in db once
	 * transaction ends.
	 */

	public void updateProduct(ProductVO productVO) throws IOException {
		Product product = dao.findById(productVO.getId());

		productVOToProduct(productVO, product);
	}

	public void deleteProductById(int id) {
		dao.deleteById(id);
	}

	public List<ProductVO> findAllProducts() throws UnsupportedEncodingException {
		List<Product> products = dao.findAllProducts();
		List<ProductVO> productsVOLst = new ArrayList<>();
		for (Product product : products) {

			productsVOLst.add(productToProductVO(product));
		}
		return productsVOLst;
		// return dao.findAllProducts();
	}

	private ProductVO productToProductVO(Product product) throws UnsupportedEncodingException {

		ProductVO productVO = new ProductVO();

		productVO.setId(product.getId());
		productVO.setName(product.getName());
		productVO.setDescription(product.getDescription());

		byte[] encodeBase64 = Base64.encodeBase64(product.getImage());
		String base64Encoded = new String(encodeBase64, "UTF-8");

		productVO.setFileBase64(base64Encoded);
		productVO.setPrice(product.getPrice());
		productVO.setProductType(product.getProductType());

		return productVO;
	}

	@Override
	public List<ProductVO> searchProducts(String productDetails, String productType)
			throws UnsupportedEncodingException {

		List<Product> products = dao.searchProducts(productDetails, productType);

		List<ProductVO> productsVOLst = new ArrayList<>();
		for (Product product : products) {

			productsVOLst.add(productToProductVO(product));
		}
		return productsVOLst;
	}

}
