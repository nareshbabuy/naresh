package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.CountryDao;
import com.oss.model.Country;
import com.oss.vo.KeyValue;

@Service("countryService")
@Transactional
public class CountryServiceImpl implements CountryService {

	@Autowired
	private CountryDao dao;

	@Override
	public List<KeyValue> findAll() {
		List<KeyValue> keyValueList = new ArrayList<>();
		for (Country entity : dao.findAll()) {
			keyValueList.add(new KeyValue(entity.getId(), entity.getName()));
		}
		return keyValueList;
	}

	@Override
	public Country findById(int id) throws UnsupportedEncodingException {
		return dao.findById(id);
	}

}
