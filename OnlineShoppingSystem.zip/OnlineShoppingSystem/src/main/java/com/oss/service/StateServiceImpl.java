package com.oss.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.StateDao;
import com.oss.model.State;
import com.oss.vo.KeyValue;

@Service("stateService")
@Transactional
public class StateServiceImpl implements StateService {

	@Autowired
	private StateDao dao;

	@Override
	public List<KeyValue> findByCountryId(int countryId) throws UnsupportedEncodingException {
		List<KeyValue> keyValueList = new ArrayList<>();
		for (State state : dao.findByCountryId(countryId)) {
			keyValueList.add(new KeyValue(state.getId(), state.getName()));
		}
		return keyValueList;
	}

	@Override
	public State findById(int id) throws UnsupportedEncodingException {
		return dao.findById(id);
	}

	@Override
	public List<KeyValue> findAll() {
		List<KeyValue> keyValueList = new ArrayList<>();
		for (State entity : dao.findAll()) {
			keyValueList.add(new KeyValue(entity.getId(), entity.getName()));
		}
		return keyValueList;
	}

}
