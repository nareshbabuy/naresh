package com.oss.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.dao.CartDao;
import com.oss.model.Cart;
import com.oss.model.Product;
import com.oss.vo.CartVO;

@Service("cartService")
@Transactional
public class CartServiceImpl implements CartService {

	@Autowired
	private CartDao dao;

	@Override
	public void save(List<Cart> cartItems) throws IOException {

		if (cartItems != null && cartItems.size() > 0) {
			for (Cart cart : cartItems)
				dao.save(cart);
		}
	}

	@Override
	public List<CartVO> findCartItemsByUserId(int userId, int isOrdered) throws UnsupportedEncodingException {
		List<Cart> cartItems = findByUserId(userId, isOrdered);
		List<CartVO> cartVOLst = new ArrayList();
		if (cartItems != null && cartItems.size() > 0) {

			for (Cart cart : cartItems) {
				CartVO cartVO = new CartVO();
				cartVO.setCartId(cart.getCartId());
				cartVO.setOrderDate(cart.getOrderDate());
				Product product = cart.getProduct();
				if (product != null) {
					cartVO.setProductId(product.getId());
					cartVO.setName(product.getName());
					cartVO.setDescription(product.getDescription());

					byte[] encodeBase64 = Base64.encodeBase64(product.getImage());
					String base64Encoded = new String(encodeBase64, "UTF-8");

					cartVO.setFileBase64(base64Encoded);
					cartVO.setPrice(product.getPrice());
					cartVO.setProductType(product.getProductType());
					
					cartVOLst.add(cartVO);
				}

			}
		}
		return cartVOLst;
	}

	@Override
	public List<Cart> findByUserId(int userId, int isOrdered) throws UnsupportedEncodingException {

		return dao.findCartItemsByUserId(userId, isOrdered);
	}

	public void deleteById(int id) {
		dao.deleteById(id);
	}

	@Override
	public void updateForOrder(int userId) throws IOException {
		List<Cart> cartItems = findByUserId(userId, 0);
		for (Cart cart : cartItems) {

			cart.setIsOrdered(1);
			cart.setOrderDate(new Timestamp(System.currentTimeMillis()));

		}

	}

}
