package com.oss.model;

import org.hibernate.validator.constraints.NotEmpty;

public class Test {

	@NotEmpty
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
