package com.oss.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "ADDRESS")
public class Address implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ADD_ID")
	private Integer addId;

	@NotEmpty
	@Column(name = "NAME")
	private String name;

	@OneToOne(fetch = FetchType.LAZY)
	private User user;

	@NotEmpty
	@Column(name = "ADDRESS")
	private String address;

	@NotEmpty
	@Column(name = "LANDMARK")
	private String landmark;

	@Min(value=1, message="Please select city")
	@Column(name = "CITY_ID")
	private int city;

	@Min(value=1, message="Please select state")
	@Column(name = "STATE_ID")
	private int state;

	@Min(value=1, message="Please select country")
	@Column(name = "Country_ID")
	private int country;

	@Pattern(regexp = "^[0-9]{6}$", message = "Pincode is invalid.")
	@Column(name = "PINCODE")
	private String pincode;

	@Pattern(regexp = "^[0-9]{10}$", message = "Phone is invalid.")
	@Column(name = "PHONE")
	private String phone;

	public Integer getAddId() {
		return addId;
	}

	public void setAddId(Integer addId) {
		this.addId = addId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getCity() {
		return city;
	}

	public void setCity(int city) {
		this.city = city;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getCountry() {
		return country;
	}

	public void setCountry(int country) {
		this.country = country;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((addId == null) ? 0 : addId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (addId == null) {
			if (other.addId != null)
				return false;
		} else if (!addId.equals(other.addId))
			return false;
		return true;
	}

}
