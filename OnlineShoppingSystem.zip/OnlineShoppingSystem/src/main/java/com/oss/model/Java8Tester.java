package com.oss.model;

import java.time.LocalDateTime;

public class Java8Tester {
	public static void main(String args[]) {
		Java8Tester java8tester = new Java8Tester();
		java8tester.testLocalDateTime();
	}

	public void testLocalDateTime() {

		// Get the current date and time
		LocalDateTime currentTime = LocalDateTime.now();
		System.out.println("Current DateTime: " + currentTime);

		int day = currentTime.getMonthValue();

		System.out.println("Month: " + day);
	}
}