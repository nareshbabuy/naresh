package com.oss.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.oss.model.Address;
import com.oss.model.Card;
import com.oss.model.Cart;
import com.oss.model.Login;
import com.oss.model.Product;
import com.oss.model.User;
import com.oss.service.AddressService;
import com.oss.service.CardService;
import com.oss.service.CartService;
import com.oss.service.CityService;
import com.oss.service.CountryService;
import com.oss.service.ProductService;
import com.oss.service.StateService;
import com.oss.service.UserService;
import com.oss.util.FileValidator;
import com.oss.vo.AddressVO;
import com.oss.vo.CardVo;
import com.oss.vo.CartVO;
import com.oss.vo.KeyValue;
import com.oss.vo.ProductVO;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class AppController {

	@Autowired
	UserService userService;

	@Autowired
	CardService cardService;

	@Autowired
	CountryService countryService;

	@Autowired
	StateService stateService;

	@Autowired
	CityService cityService;

	@Autowired
	ProductService productService;

	@Autowired
	CartService cartService;

	@Autowired
	AddressService addressService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	FileValidator fileValidator;

	private LocalDateTime currentTime = LocalDateTime.now();

	@RequestMapping(value = "/getStates-{countryId}", method = RequestMethod.GET)
	public @ResponseBody List<KeyValue> getStates(@PathVariable int countryId) throws UnsupportedEncodingException {
		System.out.println("countryId :" + countryId);
		return stateService.findByCountryId(countryId);

	}

	@RequestMapping(value = "/getCities-{stateId}", method = RequestMethod.GET)
	public @ResponseBody List<KeyValue> getCities(@PathVariable int stateId) throws UnsupportedEncodingException {
		System.out.println("stateId :" + stateId);
		return cityService.findByStateId(stateId);

	}

	@InitBinder("fileBucket")
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(fileValidator);
	}

	@RequestMapping(value = { "/deliverHere-{addressId}" }, method = RequestMethod.GET)
	public String deliverHere(@PathVariable int addressId, HttpServletRequest request) {
		request.getSession().setAttribute("addressId", addressId);
		return "redirect:/cardList";
	}

	@RequestMapping(value = { "/selectCard-{cardId}" }, method = RequestMethod.GET)
	public String selectCard(@PathVariable String cardId, HttpServletRequest request) {
		if (cardId.equals("CashOnDelivery")) {
			request.getSession().setAttribute("CashOnDelivery", true);
		} else {
			request.getSession().setAttribute("CashOnDelivery", false);
			request.getSession().setAttribute("cardId", cardId);
		}

		return "redirect:/preview";
	}

	@RequestMapping(value = { "/cardList" }, method = RequestMethod.GET)
	public String cardList(HttpServletRequest request, ModelMap model) {
		User user = (User) request.getSession().getAttribute("user");
		try {
			setHeader(model, request);
			List<CardVo> cardList = cardService.findCardVoByUserId(user.getId());
			model.addAttribute("cardList", cardList);
			return "cardList";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "redirect:/addressList";
		}

	}

	@RequestMapping(value = { "/search{productDetails}{productType}" }, method = RequestMethod.GET)
	public String search(@RequestParam String productDetails, @RequestParam String productType,
			HttpServletRequest request, ModelMap model) throws UnsupportedEncodingException {

		System.out.println("productDetails :" + productDetails);
		System.out.println("productType :" + productType);

		User user = getUser(request);
		List<ProductVO> products = null;
		try {
			products = productService.searchProducts(productDetails, productType);
		} catch (UnsupportedEncodingException e) { // TODO Auto-generated catch
													// block
			e.printStackTrace();
		}
		model.addAttribute("productsVO", products);
		if (user != null && user.getIsAdmin() == 1)
			model.addAttribute("isAdmin", true);
		else
			model.addAttribute("isAdmin", false);

		setHeader(model, request);

		return "productList";
	}

	@RequestMapping(value = { "/listProducts" }, method = RequestMethod.GET)
	public String listProducts(ModelMap model, HttpServletRequest request) throws UnsupportedEncodingException {

		User user = getUser(request);
		List<ProductVO> products = null;
		try {
			products = productService.findAllProducts();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("productsVO", products);
		if (user != null && user.getIsAdmin() == 1)
			model.addAttribute("isAdmin", true);
		else
			model.addAttribute("isAdmin", false);

		setHeader(model, request);
		return "productList";
	}

	@RequestMapping(value = { "/addressList" }, method = RequestMethod.GET)
	public String addressList(ModelMap model, HttpServletRequest request) {

		User user = getUser(request);
		try {
			setHeader(model, request);

			List<AddressVO> addressList = addressService.findVOByUserId(user.getId());
			model.addAttribute("addressList", addressList);

			return "addressList";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "redirect:/cartItems";
		}

	}

	@RequestMapping(value = { "/addNewAddress" }, method = RequestMethod.GET)
	public String addNewAddress(ModelMap model, HttpServletRequest request) throws UnsupportedEncodingException {
		Address address = new Address();
		model.addAttribute("address", address);
		model.addAttribute("edit", false);
		model.addAttribute("countryList", countryService.findAll());

		setHeader(model, request);
		return "address";
	}

	private void setHeader(ModelMap model, HttpServletRequest request) {

		User user = getUser(request);
		model.addAttribute("loggedinuser", user.getFirstName());
		model.addAttribute("cartItemsCount", cartItemsCount(user.getId()));
		model.addAttribute("userName", user.getUserName());

	}

	@RequestMapping(value = { "/addNewCard" }, method = RequestMethod.GET)
	public String addNewCard(ModelMap model, HttpServletRequest request) throws UnsupportedEncodingException {
		Card card = new Card();
		setHeader(model, request);

		model.addAttribute("card", card);
		model.addAttribute("edit", false);

		return "card";
	}

	@RequestMapping(value = { "/addNewCard" }, method = RequestMethod.POST)
	public String saveCard(@Valid Card card, BindingResult result, HttpServletRequest request, ModelMap model)
			throws UnsupportedEncodingException {

		setHeader(model, request);

		if (result.hasErrors()) {

			return "card";
		}
		int month = currentTime.getMonthValue();
		int year = currentTime.getYear();

		int monthJsp = Integer.valueOf(card.getMonth());
		int yearJsp = Integer.valueOf(card.getYear());

		if (monthJsp < month) {

			FieldError monthError = new FieldError("card", "month", "Invallid Month");
			result.addError(monthError);
			return "card";
		}

		if (yearJsp < year) {
			FieldError yearError = new FieldError("card", "year", "Invallid year");
			result.addError(yearError);
			return "card";
		}

		try {
			User user = (User) request.getSession().getAttribute("user");
			card.setUser(user);
			cardService.save(card);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "redirect:/cardList";
	}

	@RequestMapping(value = { "/addNewAddress" }, method = RequestMethod.POST)
	public String saveAddress(@Valid Address address, BindingResult result, ModelMap model, HttpServletRequest request)
			throws UnsupportedEncodingException {

		setHeader(model, request);

		if (result.hasErrors()) {

			model.addAttribute("countryList", countryService.findAll());

			return "address";
		}
		try {
			User user = (User) request.getSession().getAttribute("user");
			System.out.println("user id:" + user.getId());
			address.setUser(user);

			addressService.save(address);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/addressList";
	}

	@RequestMapping(value = { "/placeOrder-{totalAmount}" }, method = RequestMethod.GET)
	public String placeOrder(@PathVariable double totalAmount, HttpServletRequest request) {

		request.getSession().setAttribute("totalAmount", totalAmount);

		return "redirect:/addressList";
	}

	/**
	 * This method will provide the medium to add a new product.
	 * 
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = { "/newProduct" }, method = RequestMethod.GET)
	public String newProduct(ModelMap model, HttpServletRequest request) throws UnsupportedEncodingException {
		ProductVO productVO = new ProductVO();
		model.addAttribute("productVO", productVO);
		model.addAttribute("edit", false);

		setHeader(model, request);

		return "newProduct";
	}

	/**
	 * This method will provide the medium to add a new product.
	 * 
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = { "/newProduct" }, method = RequestMethod.POST)
	public String saveProduct(@Valid ProductVO productVO, BindingResult result, ModelMap model,
			HttpServletRequest request) throws UnsupportedEncodingException {

		setHeader(model, request);

		if (result.hasErrors()) {
			return "newProduct";
		}
		if (productVO.getFile() == null || productVO.getFile().getSize() == 0) {
			FieldError imError = new FieldError("productVO", "file", "Please upload image");
			result.addError(imError);
			return "newProduct";
		}

		if (productVO == null || productVO.getPrice() == null) {
			FieldError priceError = new FieldError("product", "price", "Invallid price");
			result.addError(priceError);
			return "newProduct";
		}
		try {
			productService.saveProduct(productVO);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("success", "product " + productVO.getName() + " created successfully");

		return "registrationsuccess";
	}

	/**
	 * This method will provide the medium to update an existing user.
	 * 
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = { "/editUser-{ssoId}" }, method = RequestMethod.GET)
	public String editUser(@PathVariable String ssoId, ModelMap model, HttpServletRequest request)
			throws UnsupportedEncodingException {
		User user = userService.findBySSO(ssoId);
		model.addAttribute("user", user);
		model.addAttribute("edit", true);

		setHeader(model, request);

		return "user";
	}

	@RequestMapping(value = { "/editUser-{ssoId}" }, method = RequestMethod.POST)
	public String updateUser(@PathVariable String ssoId, @Valid User user, BindingResult result, ModelMap model,
			HttpServletRequest request) throws UnsupportedEncodingException {

		if (result.hasErrors()) {
			model.addAttribute("edit", true);
			setHeader(model, request);

			return "user";
		}

		userService.updateUser(user);

		return "redirect:/listProducts";
	}

	/**
	 * This method will provide the medium to update an existing product.
	 * 
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = { "/edit-product-{id}" }, method = RequestMethod.GET)
	public String editProduct(@PathVariable int id, ModelMap model, HttpServletRequest request)
			throws UnsupportedEncodingException {

		setHeader(model, request);
		try {
			ProductVO productVO = productService.findById(id);
			model.addAttribute("productVO", productVO);
			return "viewProduct";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "productList";

	}
	
	@RequestMapping(value = { "/view-product-{id}" }, method = RequestMethod.GET)
	public String viewProduct(@PathVariable int id, ModelMap model, HttpServletRequest request)
			throws UnsupportedEncodingException {

		setHeader(model, request);
		try {
			ProductVO productVO = productService.findById(id);
			model.addAttribute("productVO", productVO);
			model.addAttribute("edit", true);
			return "viewProduct";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "productList";

	}
	

	@RequestMapping(value = { "/edit-address-{id}" }, method = RequestMethod.GET)
	public String editAddress(@PathVariable int id, ModelMap model, HttpServletRequest request) {

		try {
			setHeader(model, request);

			Address address = addressService.findById(id);
			model.addAttribute("address", address);
			model.addAttribute("edit", true);
			model.addAttribute("countryList", countryService.findAll());
			model.addAttribute("stateList", stateService.findAll());
			model.addAttribute("cityList", cityService.findAll());

			return "address";
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "addressList";

	}

	@RequestMapping(value = { "/edit-card-{id}" }, method = RequestMethod.GET)
	public String editCard(@PathVariable int id, ModelMap model, HttpServletRequest request) {

		try {
			setHeader(model, request);

			Card card = cardService.findById(id);
			model.addAttribute("card", card);
			model.addAttribute("edit", true);
			return "card";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/cardList";

	}

	@RequestMapping(value = { "/edit-address-{id}" }, method = RequestMethod.POST)
	public String updateAddress(@Valid Address address, BindingResult result, ModelMap model, @PathVariable String id,
			HttpServletRequest request) throws UnsupportedEncodingException {

		setHeader(model, request);

		if (result.hasErrors()) {
			model.addAttribute("edit", true);
			model.addAttribute("countryList", countryService.findAll());
			model.addAttribute("stateList", stateService.findAll());
			model.addAttribute("cityList", cityService.findAll());

			return "address";
		}

		try {
			addressService.updateAddress(address);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/addressList";

	}

	@RequestMapping(value = { "/edit-card-{id}" }, method = RequestMethod.POST)
	public String updateAddress(@Valid Card card, BindingResult result, ModelMap model, @PathVariable String id,
			HttpServletRequest request) throws UnsupportedEncodingException {

		if (result.hasErrors()) {
			setHeader(model, request);

			return "card";
		}

		try {
			cardService.update(card);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/cardList";

	}

	@RequestMapping(value = { "/edit-product-{id}" }, method = RequestMethod.POST)
	public String updateProduct(@Valid ProductVO productVO, BindingResult result, ModelMap model,
			@PathVariable String id, HttpServletRequest request) throws UnsupportedEncodingException {

		setHeader(model, request);

		if (result.hasErrors()) {
			model.addAttribute("edit", true);

			return "newProduct";
		}

		if (productVO != null && productVO.getPrice() == null) {
			FieldError priceError = new FieldError("product", "price", "Invallid price");
			result.addError(priceError);
			return "newProduct";
		}

		try {
			productService.updateProduct(productVO);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("success", "product " + productVO.getName() + " updated successfully");
		return "registrationsuccess";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * updating user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.POST)
	public String updateUser(@Valid User user, BindingResult result, ModelMap model, @PathVariable String ssoId,
			HttpServletRequest request) {

		setHeader(model, request);

		if (result.hasErrors()) {
			return "registration";
		}

		userService.updateUser(user);

		model.addAttribute("success",
				"User " + user.getFirstName() + " " + user.getLastName() + " updated successfully");
		return "registrationsuccess";
	}

	/**
	 * This method will delete an user by it's SSOID value.
	 */
	@RequestMapping(value = { "/delete-user-{ssoId}" }, method = RequestMethod.GET)
	public String deleteUser(@PathVariable String ssoId) {
		userService.deleteUserBySSO(ssoId);
		return "redirect:/listProducts";
	}

	@RequestMapping(value = { "/delete-address-{id}" }, method = RequestMethod.GET)
	public String deleteAddress(@PathVariable int id) {
		addressService.deleteById(id);
		return "redirect:/addressList";
	}

	@RequestMapping(value = { "/delete-card-{id}" }, method = RequestMethod.GET)
	public String deleteCard(@PathVariable int id) {
		cardService.deleteById(id);
		return "redirect:/cardList";
	}

	@RequestMapping(value = { "/delete-product-{id}" }, method = RequestMethod.GET)
	public String deleteProduct(@PathVariable int id) {
		productService.deleteProductById(id);
		return "redirect:/listProducts";
	}

	@RequestMapping(value = { "/removeItemFromCart-{id}" }, method = RequestMethod.GET)
	public String removeItemFromCart(@PathVariable int id) {
		cartService.deleteById(id);
		return "redirect:/cartItems";
	}

	@RequestMapping(value = { "/addToCart-{selectedProducts}" }, method = RequestMethod.GET)
	public String addToCart(@PathVariable String selectedProducts, HttpServletRequest request) {
		System.out.println("selectedProducts :" + selectedProducts);
		String[] selectedIds = selectedProducts.split(",");

		User user = (User) request.getSession().getAttribute("user");

		List<Cart> cartItems = new ArrayList<>();

		for (int i = 0; i < selectedIds.length; i++) {

			Cart cart = new Cart();

			cart.setCartDate(new Timestamp(System.currentTimeMillis()));
			Product product = new Product();
			product.setId(Integer.valueOf(selectedIds[i]));
			cart.setProduct(product);

			cart.setUser(user);
			cartItems.add(cart);
		}
		try {
			cartService.save(cartItems);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "redirect:/cartItems";
	}

	@RequestMapping(value = { "/cartItems" }, method = RequestMethod.GET)
	public String cartItems(HttpServletRequest request, ModelMap model) {
		User user = (User) request.getSession().getAttribute("user");
		setHeader(model, request);
		try {
			List<CartVO> cartVOLst = cartService.findCartItemsByUserId(user.getId(), 0);
			model.addAttribute("cartVOLst", cartVOLst);
			return "cart";
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "redirect:/listProducts";

	}

	@RequestMapping(value = { "/orders" }, method = RequestMethod.GET)
	public String orders(HttpServletRequest request, ModelMap model) {
		User user = (User) request.getSession().getAttribute("user");
		setHeader(model, request);
		try {
			List<CartVO> cartVOLst = cartService.findCartItemsByUserId(user.getId(), 1);
			model.addAttribute("cartVOLst", cartVOLst);
			return "orders";
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "redirect:/listProducts";

	}

	@RequestMapping(value = { "/preview" }, method = RequestMethod.GET)
	public String preview(HttpServletRequest request, ModelMap model) {
		User user = (User) request.getSession().getAttribute("user");
		setHeader(model, request);
		try {
			List<CartVO> cartVOLst = cartService.findCartItemsByUserId(user.getId(), 0);
			model.addAttribute("cartVOLst", cartVOLst);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int addressId = (int) request.getSession().getAttribute("addressId");
		try {
			model.addAttribute("address", addressService.findVOById(addressId));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		boolean cashOnDel = (boolean) request.getSession().getAttribute("CashOnDelivery");
		if (cashOnDel == true) {
			model.addAttribute("CashOnDelivery", true);
		} else {
			model.addAttribute("CashOnDelivery", false);
			String cardIdStr = (String) request.getSession().getAttribute("cardId");
			int cardId = Integer.valueOf(cardIdStr);
			try {
				model.addAttribute("card", cardService.findCardVoById(cardId));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

		}

		return "preview";

	}

	@RequestMapping(value = { "/buy" }, method = RequestMethod.GET)
	public String buy(HttpServletRequest request, ModelMap model) {
		User user = (User) request.getSession().getAttribute("user");
		setHeader(model, request);
		try {
			cartService.updateForOrder(user.getId());

			model.addAttribute("success",
					"Thank you for shopping..Order has been placed successfully. It will be delivered in 2 working days.");

			return "registrationsuccess";

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return "preview";

	}

	private int cartItemsCount(int userId) {

		List<CartVO> cartVOLst = null;
		try {
			cartVOLst = cartService.findCartItemsByUserId(userId, 0);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (cartVOLst != null)
			return cartVOLst.size();

		return 0;

	}

	/**
	 * This method handles Access-Denied redirect.
	 */
	@RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
	public String accessDeniedPage(ModelMap model, HttpServletRequest request) {
		setHeader(model, request);
		return "accessDenied";
	}

	/**
	 * This method handles login GET requests. If users is already logged-in and
	 * tries to goto login page again, will be redirected to list page.
	 */
	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public String loginPage(ModelMap model) {
		Login login = new Login();
		model.addAttribute("login", login);

		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@Valid Login login, BindingResult result, HttpServletRequest request) {

		User user = userService.findBySSO(login.getUserName());

		if (user == null) {
			FieldError monthError = new FieldError("login", "userName", "Invallid user");
			result.addError(monthError);
			return "login";
		}
		if (!login.getPassword().equals(user.getPassword())) {

			FieldError monthError = new FieldError("login", "password", "Invallid password");
			result.addError(monthError);
			return "login";
		}

		request.getSession().setAttribute("user", user);

		return "redirect:/listProducts";

	}

	/**
	 * This method handles logout requests. Toggle the handlers if you are
	 * RememberMe functionality is useless in your app.
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		request.getSession().invalidate();
		if (auth != null) {
			// new SecurityContextLogoutHandler().logout(request, response,
			// auth);
			// persistentTokenBasedRememberMeServices.logout(request, response,
			// auth);
			SecurityContextHolder.getContext().setAuthentication(null);
		}
		return "redirect:/login?logout";
	}

	/**
	 * This method returns the principal[user-name] of logged-in user.
	 */
	private User getUser(HttpServletRequest request) {

		return (User) request.getSession().getAttribute("user");

	}

	@RequestMapping(value = "/newUser-{isAdmin}", method = RequestMethod.GET)
	public String newUser(@PathVariable boolean isAdmin, ModelMap model) {

		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("edit", false);
		return "user";
	}

	@RequestMapping(value = "/newUser-{isAdmin}", method = RequestMethod.POST)
	public String saveUser(@PathVariable int isAdmin, @Valid User user, BindingResult result, ModelMap model,
			HttpServletRequest request) {

		if (result.hasErrors()) {
			return "user";
		}

		if (!userService.isUserSSOUnique(user.getId(), user.getUserName())) {
			FieldError ssoError = new FieldError("user", "userName", messageSource.getMessage("non.unique.ssoId",
					new String[] { user.getUserName() }, Locale.getDefault()));
			result.addError(ssoError);
			return "registration";
		}

		if (isAdmin == 1) {
			user.setIsAdmin(1);
		}
		userService.saveUser(user);

		if (isAdmin == 0) {
			User userLogin = userService.findBySSO(user.getUserName());
			request.getSession().setAttribute("user", userLogin);
		}

		model.addAttribute("success",
				"User " + user.getFirstName() + " " + user.getLastName() + " registered successfully");
		// return "success";
		return "registrationsuccess";
	}

}