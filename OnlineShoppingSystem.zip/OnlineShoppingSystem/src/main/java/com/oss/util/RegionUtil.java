package com.oss.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegionUtil {

	public static Map<Integer,String> countryMap() {

		Map<Integer,String> countryMap = new HashMap<>();
		
		countryMap.put(1, "U.S.A");
		countryMap.put(2, "Canada");
		countryMap.put(3, "India");
		
		return countryMap;
	}

	public static Map<Integer,String> usaSatateMap() {
		Map<Integer,String> countryMap = new HashMap<>();
		
		countryMap.put(1, "Alabama");
		countryMap.put(2, "Alaska");
		countryMap.put(3, "Arkansas");
		
		
		List<String> stateList = new ArrayList<String>();
		stateList.add("Alabama");
		stateList.add("Alaska");
		stateList.add("Arizona");
		stateList.add("Arkansas");
		stateList.add("California");
		stateList.add("Colorado");
		stateList.add("Connecticut");
		stateList.add("Delaware");
		stateList.add("Florida");
		stateList.add("Georgia");
		stateList.add("Hawaii");
		stateList.add("Idaho");
		stateList.add("Illinois");
		stateList.add("Indiana");
		stateList.add("Iowa");
		stateList.add("Kansas");
		stateList.add("Kentucky");
		stateList.add("Louisiana");
		stateList.add("Maine");
		stateList.add("Maryland");
		stateList.add("Massachusetts");
		stateList.add("Michigan");
		stateList.add("Minnesota");
		stateList.add("Mississippi");
		stateList.add("Missouri");
		stateList.add("Montana");
		stateList.add("Nebraska");
		stateList.add("Nevada");
		stateList.add("New Hampshire");
		stateList.add("New Jersey");
		stateList.add("New Mexico");
		stateList.add("New York ");
		stateList.add("	North Carolina ");
		stateList.add("North Dakota");
		stateList.add("Ohio");
		stateList.add("Oklahoma");
		stateList.add("Oregon");
		stateList.add("Pennsylvania");
		stateList.add(" Rhode Island");
		stateList.add("South Carolina ");
		stateList.add("South Dakota");
		stateList.add("Tennessee");
		stateList.add("Texas");
		stateList.add("Utah");
		stateList.add("Vermont");
		stateList.add("Virginia");
		stateList.add("Washington");
		stateList.add("West Virginia");
		stateList.add("Wisconsin ");
		stateList.add("Wyoming");

		return countryMap;
	}

	public List<String> canadaStateList() {
		List<String> canadaStateList = new ArrayList<>();

		canadaStateList.add("Alberta");
		canadaStateList.add("British Columbia");
		canadaStateList.add("Manitoba");
		canadaStateList.add("New Brunswick");
		canadaStateList.add("Newfoundland and Labrador");
		canadaStateList.add("Northwest Territories");
		canadaStateList.add("Nova Scotia");
		canadaStateList.add("Ontario");
		canadaStateList.add("Prince Edward Island");
		canadaStateList.add("Quebec");
		canadaStateList.add("Saskatchewan");
		canadaStateList.add("Yukon Territory");
		return canadaStateList;
	}

}
